Se for usar de qualquer código deste repositório altere as variaveis de ambiente
OBS: nehum trabalho será mantido nesse repositório
