package org.example;
public class FrmHelloWorld{
    public FrmHelloWorld() {

    }
}
