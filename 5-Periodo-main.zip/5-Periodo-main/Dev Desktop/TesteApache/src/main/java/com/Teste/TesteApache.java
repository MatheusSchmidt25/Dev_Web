/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.Teste;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 *
 * @author felip
 */
public class TesteApache {
    public static void main(String[] args){
        new Helloworld().setVisible(true);
      /*  BigDecimal gg = new BigDecimal("9.45");
        System.out.println(gg.setScale(1, RoundingMode.HALF_UP));*/
}
}
